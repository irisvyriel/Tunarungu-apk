import "./bootstrap";
import $ from "jquery";
